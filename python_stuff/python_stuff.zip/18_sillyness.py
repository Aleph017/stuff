import getpass

username = getpass.getuser()

user_input = input("Введите что-нибудь: ").lower()

if user_input == "amogus":
    print(f"{username} is sus!")
elif user_input == "hoi4":
    print(f"{username}? А сколько у него дивизий?")
elif user_input == "69":
    for i in range(1, 69):
        print("69")
elif user_input == "бабан":
    print("Капуста не бабан!")
elif user_input == "капуста":
    print("Бабан не Капуста!")
elif user_input == "2+2":
    print("2+2=5... нет, 6!")
elif user_input == "правда":
    print(f"А я знаю, что {username} дрочит ;)")
