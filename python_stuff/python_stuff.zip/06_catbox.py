cat_name = "Гера"
box_color = "коричневая"
box_location = "на столе"

print(f"На столе стоит коробка. В ней валяется кошка по имени {cat_name}")
print(f"Коробка {box_color} и находится {box_location}")
