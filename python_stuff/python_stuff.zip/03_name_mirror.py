name = input("Введи своё имя:")

mid_name = name.lower()[::-1]

true_name = mid_name.title()
print("Отныне тебя зовут", true_name)
