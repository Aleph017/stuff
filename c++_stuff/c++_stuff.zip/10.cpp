#include <iostream>
#include <cmath>
using namespace std;

int main(){

    int x;
   

    while(true){
        for (x = 0; x <= 1000000; x++){ 
            int equation = -5*x*x-12*x+3;
            
            if(equation == 0){
                cout << "Root of the equation is" << x << "and probably -" << x << endl;
            }
        }
    }
}
